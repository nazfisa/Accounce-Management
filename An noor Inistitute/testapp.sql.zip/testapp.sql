-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 31, 2019 at 11:12 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `testapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounce_details`
--

CREATE TABLE IF NOT EXISTS `accounce_details` (
  `line_no` int(11) NOT NULL AUTO_INCREMENT,
  `Acc_No` varchar(255) DEFAULT NULL,
  `Acc_name` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `register_time` date NOT NULL,
  PRIMARY KEY (`line_no`),
  KEY `Acc_No` (`Acc_No`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `accounce_details`
--

INSERT INTO `accounce_details` (`line_no`, `Acc_No`, `Acc_name`, `amount`, `register_time`) VALUES
(1, 'Acc-012', 'admission fee', 200, '2019-01-24'),
(2, 'Acc-012', 'admission fee', 3000, '2019-01-12');

-- --------------------------------------------------------

--
-- Table structure for table `studentpayment`
--

CREATE TABLE IF NOT EXISTS `studentpayment` (
  `line_no` int(11) NOT NULL AUTO_INCREMENT,
  `Acc_No` varchar(255) DEFAULT NULL,
  `id_no` int(11) DEFAULT NULL,
  `register_time` date NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `Acc_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`line_no`),
  KEY `id_no` (`id_no`),
  KEY `Acc_No` (`Acc_No`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=72 ;

--
-- Dumping data for table `studentpayment`
--

INSERT INTO `studentpayment` (`line_no`, `Acc_No`, `id_no`, `register_time`, `amount`, `Acc_name`) VALUES
(64, 'Acc-010', 0, '2019-01-30', 4000, 'admission fee'),
(65, 'Acc-011', 0, '2019-01-30', 4000, 'monthly fee'),
(66, 'Acc-012', 0, '2019-01-30', 4000, 'Teaching apl.'),
(67, 'Acc-010', 1, '2019-01-30', 4000, 'admission fee'),
(68, 'Acc-011', 1, '2019-01-30', 4000, 'monthly fee'),
(69, 'Acc-012', 1, '2019-01-30', 4000, 'Teaching apl.'),
(70, 'Acc-010', 0, '2019-01-31', 4000, 'admission fee'),
(71, 'Acc-011', 0, '2019-01-31', 4000, 'monthly fee');

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE IF NOT EXISTS `student_info` (
  `id_no` int(11) NOT NULL,
  `class_roll_no` varchar(255) DEFAULT NULL,
  `class` int(11) NOT NULL,
  `section` varchar(10) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `current_address` varchar(255) NOT NULL,
  `parmanent_address` varchar(255) NOT NULL,
  `mobile_no` int(11) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`id_no`, `class_roll_no`, `class`, `section`, `full_name`, `current_address`, `parmanent_address`, `mobile_no`, `gender`, `father_name`, `mother_name`, `register_date`) VALUES
(0, '10', 1, 'A', 'nazim uddn', 'hall-2, iiuc', 'feni', 18884448, 'male', 'Bhuyea mohammad maein uddin', 'Nazmun Nesa', '2018-12-26 12:01:29'),
(1, '1', 1, 'A', 'Mohammad Nazim Uddin', 'hall-2, iiuc', 'feni sadar, feni', 1885390090, 'male', 'Bhuyea mohammad maein uddin', 'Nazmun Nesa', '2018-12-16 20:16:09'),
(2, '2', 1, 'A', 'Nahida Akter', 'hall-2, iiuc', 'feni', 1885390090, 'female', 'Bhuyea mohammad maein uddin', 'Nazmun Nesa', '2018-12-16 22:27:04'),
(3, '1', 2, 'A', 'Emdad Ullah Talha', 'hall-2, iiuc', 'sonagagi feni', 1885390090, 'male', 'Mahmudul Hassan', 'Saee Millat Imami', '2018-12-16 23:20:50'),
(4, '1', 1, 'B', 'nazimuddn', 'hall-2, iiuc', 'feni', 18884448, 'male', 'Bhuyea mohammad maein uddin', 'Nazmun Nesa', '2018-12-17 12:33:43'),
(5, '4', 1, 'A', 'Emdad Ullah', 'hall-2, iiuc', 'feni', 1885390090, 'male', 'Mahmudul Hassan', 'Saee Millat Imami', '2018-12-25 14:09:47'),
(6, '3', 1, 'A', 'nazimuddn', 'hall-2, iiuc', 'feni', 18884448, 'male', 'Bhuyea mohammad maein uddin', 'Nazmun Nesa', '2018-12-25 23:08:48'),
(7, '11', 1, 'A', 'asif ullah asf', 'hall-2, iiuc', 'Feni', 1885390090, 'male', 'Bhuyea mohammad maein uddin', 'Nazmun Nesa', '2018-12-26 12:46:57'),
(8, '1', 3, 'A', 'asif ullah', 'hall-2, iiuc', 'Feni', 1885390090, 'male', 'Bhuyea mohammad maein uddin', 'Nazmun Nesa', '2018-12-26 12:48:30'),
(9, '2', 3, 'A', 'sana ullah', 'hall-2, iiuc', 'Feni', 1885390090, 'male', 'Mr. A', 'Mrs. B', '2018-12-26 13:23:36'),
(10, '2', 3, 'A', 'safi ullah', 'hall-2, iiuc', 'Feni', 1885390090, 'male', 'Mr. A', 'Mrs. B', '2018-12-26 18:17:54'),
(11, '5', 2, 'A', 'Mohammad Ibrahim', 'halishahar, ctg', 'halishahar, ctg', 1885390090, 'male', 'iqbal', 'moriom', '2019-01-29 11:06:25');

-- --------------------------------------------------------

--
-- Table structure for table `student_table`
--

CREATE TABLE IF NOT EXISTS `student_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roll` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `Mobile` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `student_table`
--

INSERT INTO `student_table` (`id`, `roll`, `name`, `address`, `Mobile`) VALUES
(1, 1111, 'nazim', 'block a, ctg', 1885390090),
(3, 122, 'nazimuddn', 'block c,halishohor', 18884448),
(5, 1233, 'asf', 'ctg', 188888890),
(6, 52, 'asif nazim', 'block b, halishohor, ctg', 1885390090),
(7, 121, 'Riaz uddin', 'kumira,ctg', 1885396690);

-- --------------------------------------------------------

--
-- Table structure for table `tblaccounce`
--

CREATE TABLE IF NOT EXISTS `tblaccounce` (
  `line_no` int(11) NOT NULL AUTO_INCREMENT,
  `Acc_No` varchar(255) DEFAULT NULL,
  `Acc_name` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `register_Time` date DEFAULT NULL,
  `Acc_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`line_no`),
  KEY `Acc_No` (`Acc_No`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tblaccounce`
--

INSERT INTO `tblaccounce` (`line_no`, `Acc_No`, `Acc_name`, `amount`, `register_Time`, `Acc_type`) VALUES
(10, 'Acc-014', 'lunch', 500, '2019-01-30', 'expense'),
(11, 'Acc-014', 'lunch', 3000, '2019-01-30', 'expense'),
(8, 'Acc-013', 'Donation', 40000, '2019-01-30', 'income');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_chart_of_account`
--

CREATE TABLE IF NOT EXISTS `tbl_chart_of_account` (
  `Acc_No` varchar(255) NOT NULL,
  `Acc_name` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Acc_type` varchar(255) NOT NULL,
  `Acc_sb_type` varchar(255) NOT NULL,
  `id_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`Acc_No`),
  KEY `id_no` (`id_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_chart_of_account`
--

INSERT INTO `tbl_chart_of_account` (`Acc_No`, `Acc_name`, `Description`, `Acc_type`, `Acc_sb_type`, `id_no`) VALUES
('Acc-010', 'admission fee', 'admission fee', 'income', 'Student', NULL),
('Acc-011', 'monthly fee', 'monthly fee', 'income', 'Student', NULL),
('Acc-012', 'Teaching apl.', 'teaching apl for student', 'income', 'Student', NULL),
('Acc-013', 'Donation', 'Donation from x organization', 'income', 'None', NULL),
('Acc-014', 'lunch', 'lunch', 'expense', 'None', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `username`, `email`, `password`) VALUES
(4, 'asif', 'asifiiuc@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(5, 'nazim uddin', 'nazim@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(6, 'asif_nazim', 'asif_nazim@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(7, 'asif12', 'asif12@gmail.com', 'e10adc3949ba59abbe56e057f20f883e');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `studentpayment`
--
ALTER TABLE `studentpayment`
  ADD CONSTRAINT `studentpayment_ibfk_1` FOREIGN KEY (`id_no`) REFERENCES `student_info` (`id_no`),
  ADD CONSTRAINT `studentpayment_ibfk_2` FOREIGN KEY (`Acc_No`) REFERENCES `tbl_chart_of_account` (`Acc_No`);

--
-- Constraints for table `tbl_chart_of_account`
--
ALTER TABLE `tbl_chart_of_account`
  ADD CONSTRAINT `tbl_chart_of_account_ibfk_1` FOREIGN KEY (`id_no`) REFERENCES `student_info` (`id_no`);
